const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const translations = {
  nl: {
    workspace:"WERKRUIMTE",overview:"Overzicht",profile:"Raceprofiel",career:"Carrièreplan",training:"Trainingscoach",teams:"Teams & series",budget:"Budget & sponsors",aiCoach:"AI-coach",prototype:"Prototype-modus",prototypeDesc:"Je gegevens blijven op dit apparaat",careerPlatform:"RACE CAREER PLATFORM",builtForRacers:"GEBOUWD VOOR DE VOLGENDE GENERATIE COUREURS",heroTitle:"Jouw racecarrière.<br><em>Jouw route.</em>",heroDesc:"Van je eerste kartmeters tot een plek in een professioneel raceteam. Krijg overzicht, maak een plan en werk doelgericht aan je volgende stap.",buildProfile:"Maak mijn raceprofiel",viewPath:"Bekijk carrièreplan",yourNextStep:"JOUW VOLGENDE STAP",yourDashboard:"JOUW DASHBOARD",startHere:"Begin hier",personalWorkspace:"Jouw persoonlijke race-werkruimte",cardProfile:"Raceprofiel",cardProfileDesc:"Leg je ervaring, doelen en mogelijkheden vast.",cardCareer:"Carrièreplan",cardCareerDesc:"Ontdek logische vervolgstappen richting jouw doel.",cardTraining:"Trainingscoach",cardTrainingDesc:"Werk aan techniek, consistentie en racecraft.",cardAI:"AI-racecoach",cardAIDesc:"Stel vragen over jouw route door de autosport.",openSection:"OPEN SECTIE",progress:"VOORTGANG",careerReadiness:"Carrièrevoorbereiding",progressDesc:"Vul je profiel in om advies te krijgen dat past bij jouw ervaring en doelen.",completeProfile:"Profiel aanvullen",quote:"Talent opent de deur. Voorbereiding, discipline en de juiste keuzes bepalen hoe ver je komt.",yourFoundation:"JOUW BASIS",profileTitle:"Jouw raceprofiel",profileIntro:"Vertel waar je nu staat. Je profiel helpt om vervolgstappen realistischer en persoonlijker te maken.",name:"Naam of bijnaam",age:"Leeftijd",country:"Land",currentLevel:"Huidig niveau",disciplines:"Interesse / discipline",experience:"Ervaring",goal:"Grootste doel",extraInfo:"Extra informatie / vragen",localSave:"Je profiel wordt lokaal in deze browser opgeslagen.",saveProfile:"Profiel opslaan ↗",routeToGoal:"ROUTE NAAR JOUW DOEL",careerTitle:"Jouw carrièreplan",careerIntro:"Een ambitieus doel wordt haalbaar als je het opdeelt in meetbare, realistische stappen.",editProfile:"Profiel bewerken",driverDevelopment:"COUREURSONTWIKKELING",trainingTitle:"Trainingscoach",trainingIntro:"Een goede training heeft één duidelijk doel. Kies een onderwerp en maak je volgende sessie concreet.",technique:"Rijtechniek",techniqueDesc:"Rempunten, trail braking, apex, throttle control en vloeiende inputs.",consistency:"Consistentie",consistencyDesc:"Leer een tempo rijden dat je meerdere ronden kunt herhalen.",racecraft:"Racecraft",racecraftDesc:"Situatiebewustzijn, positionering, verdedigen en veilig inhalen.",sessionBuilder:"TRAININGSPLANNER",buildSession:"Plan je volgende training",trainingType:"Type training",duration:"Beschikbare tijd",focus:"Focus",generateSession:"Genereer trainingssessie ↗",motorsportLandscape:"DE MOTORSPORTWERELD",teamsTitle:"Teams & kampioenschappen",teamsIntro:"Leer de verschillende routes kennen. Controleer altijd de actuele regels, kalender, kosten en licentie-eisen bij de organisator.",usefulStartingPoints:"HANDIGE STARTPUNTEN",officialResources:"Officiële informatie",financialPlanning:"FINANCIËLE PLANNING",budgetTitle:"Budget & sponsors",budgetIntro:"Maak kosten zichtbaar voordat je een stap zet. Een realistische begroting voorkomt verrassingen.",budgetPlanner:"BUDGETPLANNER",estimateCosts:"Schat je seizoensbudget",entryFees:"Inschrijvingen (€)",equipment:"Uitrusting (€)",travel:"Reizen & verblijf (€)",testing:"Testen / training (€)",maintenance:"Materiaal / onderhoud (€)",other:"Overig / reserve (€)",estimatedTotal:"GESCHAT TOTAAL PER SEIZOEN",sponsorToolkit:"SPONSOR TOOLKIT",beSponsorReady:"Maak jezelf sponsorwaardig",yourRaceAdvisor:"JOUW RACEADVISEUR",coachTitle:"Praat met je AI-racecoach",coachIntro:"Stel vragen over je volgende stap, training, budget, licenties of een raceklasse.",coachReady:"Coachprototype · klaar om te helpen",welcomeChat:"Welkom! Ik help je nadenken over je racecarrière. Vertel me waar je nu staat en wat je wilt bereiken. Voor persoonlijk advies kun je eerst je raceprofiel invullen.",chatPlaceholder:"Stel je vraag...",chatDisclaimer:"Prototype: voorbeeldantwoorden. Voor een live AI-model moet de Cloudflare AI-koppeling worden ingesteld.",coachGuidelines:"RICHTLIJNEN VOOR DE COACH",honestAdvice:"Eerlijk advies. Geen loze beloftes.",honestAdviceDesc:"Een goede coach kijkt naar je niveau, middelen, veiligheid en de realiteit van de sport.",guide1:"Realistische vervolgstappen",guide2:"Aandacht voor veiligheid",guide3:"Budget en alternatieven",guide4:"Geen garanties op een racecarrière",personalizeCoach:"Personaliseer je coach →",footerText:"Gebouwd voor de volgende generatie coureurs."
  },
  en: {
    workspace:"WORKSPACE",overview:"Overview",profile:"Racing profile",career:"Career roadmap",training:"Training coach",teams:"Teams & series",budget:"Budget & sponsors",aiCoach:"AI coach",prototype:"Prototype mode",prototypeDesc:"Your data stays on this device",careerPlatform:"RACING CAREER PLATFORM",builtForRacers:"BUILT FOR THE NEXT GENERATION OF RACERS",heroTitle:"Your racing career.<br><em>Your path.</em>",heroDesc:"From your first karting laps to a seat with a professional racing team. Get clarity, build a plan and work towards your next step.",buildProfile:"Build my racing profile",viewPath:"View career roadmap",yourNextStep:"YOUR NEXT STEP",yourDashboard:"YOUR DASHBOARD",startHere:"Start here",personalWorkspace:"Your personal racing workspace",cardProfile:"Racing profile",cardProfileDesc:"Capture your experience, goals and resources.",cardCareer:"Career roadmap",cardCareerDesc:"Explore logical next steps towards your goal.",cardTraining:"Training coach",cardTrainingDesc:"Develop technique, consistency and racecraft.",cardAI:"AI racing coach",cardAIDesc:"Ask questions about your route through motorsport.",openSection:"OPEN SECTION",progress:"PROGRESS",careerReadiness:"Career preparation",progressDesc:"Complete your profile to get advice that fits your experience and goals.",completeProfile:"Complete profile",quote:"Talent opens the door. Preparation, discipline and the right decisions determine how far you go.",yourFoundation:"YOUR FOUNDATION",profileTitle:"Your racing profile",profileIntro:"Tell us where you are today. Your profile helps make next steps more realistic and personal.",name:"Name or nickname",age:"Age",country:"Country",currentLevel:"Current level",disciplines:"Interest / discipline",experience:"Experience",goal:"Main goal",extraInfo:"Extra information / questions",localSave:"Your profile is saved locally in this browser.",saveProfile:"Save profile ↗",routeToGoal:"ROUTE TO YOUR GOAL",careerTitle:"Your career roadmap",careerIntro:"An ambitious goal becomes more achievable when you break it into measurable, realistic steps.",editProfile:"Edit profile",driverDevelopment:"DRIVER DEVELOPMENT",trainingTitle:"Training coach",trainingIntro:"Good training has one clear objective. Choose a topic and make your next session specific.",technique:"Driving technique",techniqueDesc:"Braking points, trail braking, apexes, throttle control and smooth inputs.",consistency:"Consistency",consistencyDesc:"Learn to repeat a pace over multiple laps.",racecraft:"Racecraft",racecraftDesc:"Situational awareness, positioning, defending and safe overtaking.",sessionBuilder:"SESSION BUILDER",buildSession:"Plan your next training session",trainingType:"Training type",duration:"Available time",focus:"Focus",generateSession:"Generate training session ↗",motorsportLandscape:"THE MOTORSPORT LANDSCAPE",teamsTitle:"Teams & championships",teamsIntro:"Explore different routes. Always check current rules, calendars, costs and licence requirements with the organiser.",usefulStartingPoints:"USEFUL STARTING POINTS",officialResources:"Official information",financialPlanning:"FINANCIAL PLANNING",budgetTitle:"Budget & sponsors",budgetIntro:"Make costs visible before taking the next step. A realistic budget prevents surprises.",budgetPlanner:"BUDGET PLANNER",estimateCosts:"Estimate your season budget",entryFees:"Entry fees (€)",equipment:"Equipment (€)",travel:"Travel & accommodation (€)",testing:"Testing / training (€)",maintenance:"Equipment / maintenance (€)",other:"Other / reserve (€)",estimatedTotal:"ESTIMATED SEASON TOTAL",sponsorToolkit:"SPONSOR TOOLKIT",beSponsorReady:"Become sponsor-ready",yourRaceAdvisor:"YOUR RACE ADVISOR",coachTitle:"Talk to your AI racing coach",coachIntro:"Ask about your next step, training, budget, licences or a racing series.",coachReady:"Coach prototype · ready to help",welcomeChat:"Welcome! I can help you think through your racing career. Tell me where you are now and what you want to achieve. Complete your racing profile first for more personal advice.",chatPlaceholder:"Ask your question...",chatDisclaimer:"Prototype: sample answers. A live AI model requires the Cloudflare AI connection to be configured.",coachGuidelines:"COACH GUIDELINES",honestAdvice:"Honest advice. No empty promises.",honestAdviceDesc:"A good coach considers your level, resources, safety and the realities of the sport.",guide1:"Realistic next steps",guide2:"Safety comes first",guide3:"Budget and alternatives",guide4:"No guarantees of a racing career",personalizeCoach:"Personalise your coach →",footerText:"Built for the next generation of racers."
  }
};
let language = localStorage.getItem("rp_language") || "nl";
let profile = JSON.parse(localStorage.getItem("rp_profile") || "{}");
const pageNames = {home:{nl:"Overzicht",en:"Overview"},profile:{nl:"Raceprofiel",en:"Racing profile"},career:{nl:"Carrièreplan",en:"Career roadmap"},training:{nl:"Trainingscoach",en:"Training coach"},teams:{nl:"Teams & series",en:"Teams & series"},budget:{nl:"Budget & sponsors",en:"Budget & sponsors"},coach:{nl:"AI-coach",en:"AI coach"}};

function translate(){
  document.documentElement.lang = language;
  $$("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[language][key])el.innerHTML=translations[language][key]});
  $$("[data-i18n-placeholder]").forEach(el=>{const key=el.dataset.i18nPlaceholder;if(translations[language][key])el.placeholder=translations[language][key]});
  $("#pageCrumb").textContent=pageNames[currentPage][language];
  $("#languageBtn").textContent=language==="nl"?"NL / EN":"EN / NL";
}
let currentPage="home";
function navigate(page){
  if(!pageNames[page])page="home";
  currentPage=page;
  $$(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));
  $$(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.page===page));
  $("#pageCrumb").textContent=pageNames[page][language];
  history.replaceState(null,"","#"+page);
  window.scrollTo({top:0,behavior:"smooth"});
}
document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-page], [data-page-link]");
  if(nav){e.preventDefault();navigate(nav.dataset.page||nav.dataset.pageLink)}
});
$("#languageBtn").addEventListener("click",()=>{language=language==="nl"?"en":"nl";localStorage.setItem("rp_language",language);translate()});

function loadProfile(){
  const form=$("#profileForm");
  Object.entries(profile).forEach(([key,value])=>{if(form.elements[key])form.elements[key].value=value});
  const count=["name","age","level","discipline","experience","budget","goal"].filter(k=>profile[k]).length;
  const pct=Math.round(count/7*100);
  $("#profileProgress").style.width=pct+"%";$("#profileStatus").textContent=pct+"%";
  $("#avatar").textContent=(profile.name||"R").trim().charAt(0).toUpperCase();
  $("#heroNextStep").textContent=profile.name?(language==="nl"?"Maak je volgende stap concreet":"Define your next step"):"Build your profile";
  updateCareer();
}
$("#profileForm").addEventListener("submit",e=>{
  e.preventDefault();profile=Object.fromEntries(new FormData(e.currentTarget).entries());
  localStorage.setItem("rp_profile",JSON.stringify(profile));loadProfile();
  $("#profileSaved").textContent=language==="nl"?"Je profiel is opgeslagen op dit apparaat.":"Your profile has been saved on this device.";
});
function updateCareer(){
  const name=profile.name|| (language==="nl"?"coureur":"driver");
  $("#careerGreeting").textContent=language==="nl"?`Bouw ${name==="coureur"?"jouw":name+"’s"} route naar de grid.`:`Build ${name==="driver"?"your":name+"'s"} route to the grid.`;
  const level=profile.level||"";
  let summary=language==="nl"?"Vul eerst je raceprofiel in. Dan kunnen we een route op hoofdlijnen samenstellen.":"Complete your racing profile first. Then we can outline a route.";
  if(level)summary=language==="nl"?`Je huidige niveau is ${level}. De beste volgende stap hangt af van je discipline, ervaring, budget en beschikbare trainingstijd.`:`Your current level is ${level}. The best next step depends on your discipline, experience, budget and available training time.`;
  $("#careerSummary").textContent=summary;
}
const trainingPlans={
  "Consistentie":["Warming-up: 5–10 minuten rustig opbouwen.","Rijd 3 blokken met gelijke lengte en neem korte pauzes.","Noteer per blok je rondetijden en één terugkerende fout.","Doel: kleinere verschillen tussen je representatieve rondes."],
  "Remtechniek":["Kies één veilige, overzichtelijke remzone.","Let op een vaste referentie, geleidelijke drukopbouw en gecontroleerd lossen.","Verander niet tegelijk je rempunt én instuurmoment.","Doel: herhaalbare remacties zonder onnodige risico's."],
  "Racecraft":["Oefen eerst met overzicht en ruimte inschatten.","Bekijk onboardbeelden en benoem mogelijke keuzes vóór de bocht.","Rijd alleen oefenduels in een geschikte, gecontroleerde setting.","Doel: beslissingen vroeg nemen en ruimte respecteren."],
  "Bochtensnelheid":["Kies één bocht en analyseer instuurpunt, apex en uitkomen.","Vergelijk minimum speed en snelheid op het rechte stuk.","Maak kleine aanpassingen en verander één variabele tegelijk.","Doel: een vloeiende, herhaalbare lijn."],
  "Data-analyse":["Sla een representatieve sessie op.","Vergelijk rempunt, minimum speed en gasmoment met je eigen beste ronde.","Zoek één verschil dat je veilig kunt testen.","Doel: één concrete aanpassing voor de volgende sessie."]
};
$("#makeSession").addEventListener("click",()=>{
  const type=$("#sessionType").value,duration=$("#sessionDuration").value,focus=$("#sessionFocus").value;
  const list=trainingPlans[focus];
  $("#sessionResult").classList.remove("hidden");
  $("#sessionResult").innerHTML=`<h4>${type} / ${duration} / ${focus}</h4><ol>${list.map(x=>`<li>${x}</li>`).join("")}</ol><b>${language==="nl"?"Reflectie na afloop:":"Post-session reflection:"}</b> ${language==="nl"?"Wat ging beter? Wat wordt je enige focus voor de volgende sessie?":"What improved? What will be your single focus next session?"}`;
});
const budgetInputs=["entryFees","equipment","travel","testing","maintenance","other"];
function updateBudget(){const total=budgetInputs.reduce((sum,id)=>sum+Math.max(0,Number($("#"+id).value)||0),0);$("#budgetTotal").textContent=total.toLocaleString(language==="nl"?"nl-NL":"en-GB",{style:"currency",currency:"EUR",maximumFractionDigits:0});}
budgetInputs.forEach(id=>$("#"+id).addEventListener("input",updateBudget));

function answerFor(question){
  const q=question.toLowerCase(),isEn=language==="en";
  if(/kart|begin/.test(q))return isEn?"Start by learning the basics in a safe, supervised karting environment. Compare local clubs, coaching options and total costs. Focus on consistency and racecraft before buying equipment or entering an expensive championship. Check the organiser's current age, licence and safety requirements.":"Begin met de basis in een veilige, begeleide kartomgeving. Vergelijk lokale clubs, lessen en totale kosten. Werk eerst aan consistentie en racecraft voordat je dure uitrusting koopt of een kampioenschap instapt. Controleer de actuele leeftijds-, licentie- en veiligheidseisen bij de organisator.";
  if(/gt3|gt4|ferrari|profession/.test(q))return isEn?"GT3 is a high-level and expensive part of motorsport. A sensible route is to build measurable results in an appropriate entry category, gain race experience, understand licence progression and create a credible driver CV. GT4 can be one possible step, but it is not mandatory for everyone. Team seats and funding are highly competitive.":"GT3 is een hoog en kostbaar niveau binnen de autosport. Een verstandige route is om meetbare resultaten op te bouwen in een passende instapklasse, wedstrijdervaring op te doen, licentie-eisen te begrijpen en een geloofwaardig race-cv te maken. GT4 kan een mogelijke tussenstap zijn, maar is niet voor iedereen verplicht. Teamstoelen en financiering zijn zeer competitief.";
  if(/sponsor|geld|budget|kosten/.test(q))return isEn?"Create a realistic season budget first: entries, testing, equipment, travel, maintenance, coaching and contingency. A sponsor proposal should explain your story, audience, results and exactly what value the partner receives. Do not promise exposure or results you cannot guarantee.":"Maak eerst een realistische seizoensbegroting: inschrijvingen, testen, uitrusting, reizen, onderhoud, coaching en reserve. Een sponsorvoorstel moet jouw verhaal, doelgroep, resultaten en concrete tegenprestatie uitleggen. Beloof geen bereik of resultaten die je niet kunt garanderen.";
  if(/licen[cs]|knaf|fia/.test(q))return isEn?"Licence requirements depend on the country, discipline and championship. Check the current rules directly with the relevant national federation and organiser before paying for a course or event. In the Netherlands, KNAF is an important starting point for car and karting competition information.":"Licentie-eisen verschillen per land, discipline en kampioenschap. Controleer de actuele regels rechtstreeks bij de nationale bond en organisator voordat je een cursus of evenement betaalt. In Nederland is de KNAF een belangrijk startpunt voor informatie over auto- en kartsport.";
  if(/sim|iracing|acc/.test(q))return isEn?"Treat simracing like structured practice: choose a series, learn the sporting code, prioritise clean finishes and consistency, then review telemetry and race footage. Build a results record before approaching teams. A high rating alone does not guarantee a team seat.":"Behandel simracing als gestructureerde training: kies een serie, leer het sportreglement, focus op schone finishes en consistentie en analyseer daarna telemetry en racebeelden. Bouw eerst een resultatenoverzicht op voordat je teams benadert. Een hoge rating alleen garandeert geen teamplek.";
  return isEn?"A useful next step depends on your current level, discipline, available budget and goal. Complete your racing profile and tell me what you have done so far. I can then help compare realistic options, costs and the next skills to develop.":"Een goede volgende stap hangt af van je huidige niveau, discipline, beschikbare budget en doel. Vul je raceprofiel in en vertel wat je tot nu toe hebt gedaan. Dan kan ik helpen om realistische opties, kosten en vaardigheden te vergelijken.";
}
function addMessage(text,who){
  const wrap=document.createElement("div");wrap.className="message "+who;
  const label=document.createElement("small");label.textContent=who==="user"?(profile.name||"YOU").toUpperCase():"RACEPATH AI";
  const p=document.createElement("p");p.textContent=text;wrap.append(label,p);$("#chatMessages").append(wrap);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;
}
// Paste your deployed Cloudflare Worker URL here to enable live AI.
// Leave empty to use the built-in demo answers.
const AI_API_ENDPOINT = "";
async function sendChat(text){
  if(!text.trim())return;
  addMessage(text,"user");$("#chatInput").value="";
  if(AI_API_ENDPOINT){
    const pending=document.createElement("div");pending.className="message assistant";
    pending.innerHTML="<small>RACEPATH AI</small><p>Thinking…</p>";
    $("#chatMessages").append(pending);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight;
    try{
      const response=await fetch(AI_API_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,profile,language})});
      const data=await response.json();
      pending.remove();
      addMessage(data.reply||data.error||"The AI service returned no answer.","assistant");
    }catch(error){
      pending.remove();
      addMessage(language==="nl"?"De live AI is momenteel niet bereikbaar. Controleer de Worker-URL en probeer opnieuw.":"The live AI is currently unavailable. Check the Worker URL and try again.","assistant");
    }
  }else{
    setTimeout(()=>addMessage(answerFor(text),"assistant"),250);
  }
}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();sendChat($("#chatInput").value)});
$$(".suggestion").forEach(btn=>btn.addEventListener("click",()=>sendChat(btn.textContent)));
translate();loadProfile();updateBudget();
const initial=(location.hash||"#home").slice(1);navigate(pageNames[initial]?initial:"home");
