// Optional Cloudflare Worker AI backend.
// Deploy this Worker and bind the Cloudflare Workers AI service as "AI".
// Then set the frontend API endpoint in app.js to this Worker URL.
// Never put an API token or secret in browser JavaScript.

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });

    try {
      const body = await request.json();
      const message = String(body.message || "").slice(0, 3000);
      const profile = body.profile && typeof body.profile === "object" ? body.profile : {};
      const language = body.language === "en" ? "English" : "Dutch";
      if (!message.trim()) return Response.json({ error: "Message is required" }, { status: 400, headers: cors });

      const system = `You are RacePath AI, a realistic and safety-first motorsport career coach. Reply in ${language}. Help users with karting, simracing, circuit racing, GT, endurance, formula, rally, training, licences, teams, budgets and sponsorship. Ask clarifying questions when needed. Be honest: never guarantee a professional seat, income, sponsorship or career outcome. Explain that costs, age rules, licences and calendars vary and must be checked with the current organiser or national federation. Do not encourage unsafe driving, illegal street racing, rule evasion or training beyond the user's supervision and competence. Do not invent current prices, regulations or team vacancies. Distinguish general guidance from verified current facts. Give practical, staged advice and consider the user's profile when relevant. Profile: ${JSON.stringify(profile).slice(0, 1800)}`;

      const result = await env.AI.run("@cf/meta/llama-3.1-8b-instruct", {
        messages: [
          { role: "system", content: system },
          { role: "user", content: message }
        ],
        max_tokens: 700
      });
      const reply = result.response || result.output_text || "Sorry, I couldn't generate a response.";
      return Response.json({ reply }, { headers: cors });
    } catch (error) {
      return Response.json({ error: "AI service unavailable. Check the Worker AI binding and deployment." }, { status: 500, headers: cors });
    }
  }
};
