# RacePath AI — eerste versie

Een responsive, tweetalige (Nederlands/Engels) motorsport-carrièrewebsite.

## Wat zit erin?
- Overzicht/dashboard
- Raceprofiel met lokale opslag in de browser
- Eerste carrière-roadmap
- Trainingssessie-generator
- Overzicht van motorsportdisciplines en officiële startlinks
- Budgetcalculator en sponsoradvies
- Chat-prototype met voorbeeldantwoorden
- Optionele Cloudflare Workers AI-backend (`worker.js`)

## Belangrijk over de AI-chat
De chat in de eerste versie gebruikt voorbeeldantwoorden in `app.js`. Dat maakt de demo direct testbaar, maar het is nog geen live generatieve AI.

Er staat een optionele backend in `worker.js` klaar voor Cloudflare Workers AI. Om die te activeren:
1. Maak een gratis Cloudflare-account.
2. Deploy `worker.js` als Worker.
3. Voeg in de Worker-instellingen een Workers AI binding toe met de variabelenaam `AI`.
4. Controleer de actuele gratis gebruikslimieten van Cloudflare Workers AI.
5. Kopieer de Worker-URL.
6. Open `app.js` en plak die URL in `AI_API_ENDPOINT` (zoek op die naam).
7. Upload de aangepaste `app.js` opnieuw naar je hosting.
8. Test de chat. Gebruik nooit een geheime API-key in frontend-code.

De gratis AI-limiet en voorwaarden kunnen wijzigen. Een gratis hostingplan betekent niet automatisch onbeperkte AI-antwoorden.

## Lokaal testen
Open `index.html` in een moderne browser. Er is geen build-stap nodig. Google Fonts wordt online geladen; zonder internet gebruikt de browser een fallback-lettertype.

## Gratis online zetten met GitHub Pages
1. Maak een account op https://github.com/.
2. Maak een nieuwe repository, bijvoorbeeld `racepath-ai`.
3. Upload `index.html`, `styles.css`, `app.js` en eventueel `README.md`.
4. Open **Settings → Pages**.
5. Kies **Deploy from a branch**, selecteer `main` en `/ (root)`, en sla op.
6. GitHub toont daarna je gratis websiteadres.

Je hebt voor GitHub Pages geen betaald domein nodig. Het adres wordt ongeveer:
`https://JOUW-GITHUB-NAAM.github.io/racepath-ai/`

## Gratis online zetten met Cloudflare Pages
1. Maak een account op https://dash.cloudflare.com/.
2. Ga naar **Workers & Pages → Create → Pages**.
3. Koppel een GitHub-repository of upload de projectbestanden volgens de actuele Pages-flow.
4. Gebruik geen build command; de output directory is de project-root (`/`).
5. Na deploy krijg je een gratis `pages.dev`-adres.

## Privacy en beperkingen van deze demo
- Profielgegevens worden alleen in de lokale browser opgeslagen via `localStorage`.
- Er is nog geen account/login, database, synchronisatie of beheeromgeving.
- Deel geen gevoelige persoonsgegevens in het prototype.
- De informatie over series en licenties is algemeen. Controleer altijd de actuele regels bij de organisator/bond.
- De site is geen vervanging voor een gekwalificeerde racecoach, medische beoordeling of officiële regelgeving.
